package io.realmmc.clip.plugin.managers;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import io.realmmc.clip.plugin.RealmMC;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.logging.Level;

public class SchematicManager {

    private final RealmMC plugin;
    private final boolean worldEditAvailable;

    public SchematicManager(RealmMC plugin) {
        this.plugin = plugin;
        this.worldEditAvailable = Bukkit.getPluginManager().getPlugin("WorldEdit") != null;
        if (worldEditAvailable) {
            plugin.getLogger().info("WorldEdit bulundu - .schem import aktif.");
        } else {
            plugin.getLogger().warning("WorldEdit bulunamadı - /realm schem komutu çalışmayacak.");
        }
    }

    public boolean isAvailable() {
        return worldEditAvailable;
    }

    public boolean pasteSchematic(Player player, String fileName) {
        if (!worldEditAvailable) {
            player.sendMessage("§cWorldEdit yüklü değil!");
            return false;
        }

        File schemFolder = getSchematicsFolder();
        File schemFile = new File(schemFolder, fileName.endsWith(".schem") ? fileName : fileName + ".schem");
        if (!schemFile.exists()) {
            schemFile = new File(schemFolder, fileName);
            if (!schemFile.exists()) {
                player.sendMessage("§cSchematic bulunamadı: §e" + fileName);
                player.sendMessage("§7Dosyayı koy: §fplugins/RealmMC/schematics/");
                player.sendMessage("§7veya internetten indir: §e/realm schem url <link>");
                return false;
            }
        }

        return pasteFile(player, schemFile);
    }

    public void downloadAndPaste(Player player, String urlString) {
        if (!worldEditAvailable) {
            player.sendMessage("§cWorldEdit yüklü değil!");
            return;
        }

        player.sendMessage("§eSchematic indiriliyor...");

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                URL url = URI.create(urlString).toURL();
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("User-Agent", "RealmMC/1.0");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(30000);

                int code = conn.getResponseCode();
                if (code != 200) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            player.sendMessage("§cİndirme başarısız: HTTP " + code));
                    return;
                }

                String rawName = urlString.substring(urlString.lastIndexOf('/') + 1);
                final String fileName;
                if (!rawName.endsWith(".schem") && !rawName.endsWith(".schematic")) {
                    fileName = "downloaded_" + System.currentTimeMillis() + ".schem";
                } else {
                    fileName = rawName;
                }

                final File outFile = new File(getSchematicsFolder(), fileName);
                try (InputStream in = conn.getInputStream();
                     FileOutputStream out = new FileOutputStream(outFile)) {
                    in.transferTo(out);
                }

                Bukkit.getScheduler().runTask(plugin, () -> {
                    player.sendMessage("§aİndirildi: §e" + fileName);
                    pasteFile(player, outFile);
                });

            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Schem download error", e);
                Bukkit.getScheduler().runTask(plugin, () ->
                        player.sendMessage("§cİndirme hatası: " + e.getMessage()));
            }
        });
    }

    private boolean pasteFile(Player player, File schemFile) {
        Location loc = player.getLocation();
        try {
            ClipboardFormat format = ClipboardFormats.findByFile(schemFile);
            if (format == null) {
                player.sendMessage("§cDesteklenmeyen schematic formatı!");
                return false;
            }

            try (ClipboardReader reader = format.getReader(new FileInputStream(schemFile))) {
                Clipboard clipboard = reader.read();

                try (EditSession editSession = WorldEdit.getInstance().newEditSession(BukkitAdapter.adapt(loc.getWorld()))) {
                    Operation operation = new ClipboardHolder(clipboard)
                            .createPaste(editSession)
                            .to(BlockVector3.at(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()))
                            .ignoreAirBlocks(false)
                            .build();
                    Operations.complete(operation);
                }
            }

            player.sendMessage("§aSchematic başarıyla yüklendi: §e" + schemFile.getName());
            return true;

        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Schematic paste hatası", e);
            player.sendMessage("§cSchematic yüklenirken hata: " + e.getMessage());
            return false;
        }
    }

    public File getSchematicsFolder() {
        File folder = new File(plugin.getDataFolder(), "schematics");
        if (!folder.exists()) folder.mkdirs();
        return folder;
    }
}
