package io.realmmc.clip.plugin.gui;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.market.MarketPlugin;
import io.realmmc.clip.plugin.models.Realm;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class MarketGUI {

    private final RealmMC plugin;

    public MarketGUI(RealmMC plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Realm realm = plugin.getRealmManager().getPlayerRealm(player);
        if (realm == null) {
            player.sendMessage("§cPlugin marketi sadece realm içinde kullanılabilir!");
            return;
        }
        if (!realm.isOwner(player.getUniqueId()) && !realm.getRank(player.getUniqueId()).equals("admin")) {
            player.sendMessage("§cSadece owner/admin eklenti yönetebilir.");
            return;
        }

        Inventory inv = Bukkit.createInventory(null, 54,
                Component.text("Plugin Market - " + realm.getName(), NamedTextColor.AQUA, TextDecoration.BOLD));

        int slot = 10;
        for (MarketPlugin mp : plugin.getMarketManager().getAll()) {
            if (slot == 17) slot = 19;
            if (slot == 26) slot = 28;
            if (slot >= 35) break;

            boolean on = plugin.getMarketManager().isEnabled(realm.getId(), mp.getId());
            List<String> lore = new ArrayList<>();
            lore.add("§7" + mp.getDescription());
            lore.add("");
            lore.add("§7Yazar: §f" + mp.getAuthor());
            lore.add("§7Sürüm: §f" + mp.getVersion());
            lore.add("§7Fiyat: §f" + (mp.getPrice() == 0 ? "Ücretsiz" : mp.getPrice() + " coin"));
            lore.add("");
            lore.add(on ? "§a✔ Kurulu" : "§c✘ Kurulu değil");
            lore.add("§eTıkla: " + (on ? "Kaldır" : "Kur"));

            ItemStack item = new ItemStack(mp.getIcon());
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName((on ? "§a" : "§7") + mp.getName());
            meta.setLore(lore);
            // Store plugin id in localized name or PDC - use lore last line trick / display
            item.setItemMeta(meta);
            inv.setItem(slot, item);
            slot++;
        }

        inv.setItem(49, item(Material.ARROW, "§eGeri", "§7Realm ayarlarına dön"));
        inv.setItem(45, item(Material.BOOK, "§bDeveloper Bilgi",
                "§7Kendi eklentini eklemek için:",
                "§fplugins/RealmMC/market/ §7klasörüne",
                "§f.yml §7dosyası koy (id, name, description...)",
                "§7Sonra: §e/realm market reload"));

        player.openInventory(inv);
    }

    private ItemStack item(Material mat, String name, String... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        List<String> lore = new ArrayList<>();
        for (String line : loreLines) lore.add(line);
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
