package io.realmmc.clip.plugin.commands;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.gui.RealmGUI;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RealmCommand implements CommandExecutor, TabCompleter {

    private final RealmMC plugin;

    public RealmCommand(RealmMC plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Sadece oyuncular kullanabilir.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> {
                if (!player.hasPermission("realmmc.create")) {
                    player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage("§cKullanım: /realm create <isim> [NORMAL|FLAT|AMPLIFIED|LARGE_BIOMES]");
                    return true;
                }
                String worldType = "NORMAL";
                String name;
                if (args.length >= 3 && isWorldType(args[args.length - 1])) {
                    worldType = args[args.length - 1].toUpperCase();
                    name = String.join(" ", Arrays.copyOfRange(args, 1, args.length - 1));
                } else {
                    name = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                }
                plugin.getRealmManager().createRealm(player, name, worldType);
            }
            case "join" -> {
                if (args.length < 2) {
                    player.sendMessage("§cKullanım: /realm join <id>");
                    return true;
                }
                plugin.getRealmManager().joinRealm(player, args[1]);
            }
            case "leave" -> plugin.getRealmManager().leaveRealm(player);
            case "list" -> {
                player.sendMessage("§e§l=== Realms ===");
                for (Realm r : plugin.getRealmManager().getAllRealms()) {
                    player.sendMessage("§7- §a" + r.getName() + " §8(ID: " + r.getId() + ") §7Tip: §f" + r.getWorldType());
                }
            }
            case "info" -> {
                Realm current = plugin.getRealmManager().getPlayerRealm(player);
                if (current == null) {
                    player.sendMessage("§cŞu an bir realm'de değilsin.");
                    return true;
                }
                player.sendMessage("§e§l=== Realm Info ===");
                player.sendMessage("§7İsim: §f" + current.getName());
                player.sendMessage("§7ID: §f" + current.getId());
                player.sendMessage("§7Rank: §f" + current.getRank(player.getUniqueId()));
                player.sendMessage("§7Public: §f" + current.isPublic());
                player.sendMessage("§7Dünya tipi: §f" + current.getWorldType());
                player.sendMessage("§7Resource Pack: §f" + (current.getResourcePackUrl() != null ? "Var" : "Yok"));
                player.sendMessage("§7Scoreboard: §f" + (current.isScoreboardEnabled() ? "Açık" : "Kapalı"));
            }
            case "gui", "menu" -> new RealmGUI(plugin).openMain(player);
            case "setspawn" -> {
                Realm current = plugin.getRealmManager().getPlayerRealm(player);
                if (current == null || !current.isOwner(player.getUniqueId())) {
                    player.sendMessage("§cSadece kendi realm'inde spawn ayarlayabilirsin.");
                    return true;
                }
                current.setSpawn(player.getLocation());
                plugin.getRealmManager().saveAll();
                player.sendMessage("§aSpawn ayarlandı!");
            }
            case "schem", "schematic" -> {
                if (!player.hasPermission("realmmc.schem")) {
                    player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));
                    return true;
                }
                Realm current = plugin.getRealmManager().getPlayerRealm(player);
                if (current == null) {
                    player.sendMessage("§cÖnce bir realm'e girmen lazım!");
                    return true;
                }
                if (!current.isOwner(player.getUniqueId()) && !current.getRank(player.getUniqueId()).equals("admin")) {
                    player.sendMessage("§cSadece owner veya admin schematic yükleyebilir.");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage("§cKullanım:");
                    player.sendMessage("§e/realm schem <dosyaadı>");
                    player.sendMessage("§e/realm schem url <https://...schem>");
                    return true;
                }
                if (args[1].equalsIgnoreCase("url")) {
                    if (args.length < 3) {
                        player.sendMessage("§cKullanım: /realm schem url <link>");
                        return true;
                    }
                    plugin.getSchematicManager().downloadAndPaste(player, args[2]);
                } else {
                    plugin.getSchematicManager().pasteSchematic(player, args[1]);
                }
            }
            case "pack", "resourcepack" -> {
                Realm current = plugin.getRealmManager().getPlayerRealm(player);
                if (current == null || !current.isOwner(player.getUniqueId())) {
                    player.sendMessage("§cSadece kendi realm'inde resource pack ayarlayabilirsin.");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage("§cKullanım: /realm pack <url|clear>");
                    player.sendMessage("§7Örnek: /realm pack https://example.com/pack.zip");
                    return true;
                }
                if (args[1].equalsIgnoreCase("clear")) {
                    current.setResourcePackUrl(null);
                    plugin.getRealmManager().saveAll();
                    player.sendMessage("§aResource pack kaldırıldı.");
                } else {
                    current.setResourcePackUrl(args[1]);
                    plugin.getRealmManager().saveAll();
                    player.setResourcePack(args[1]);
                    player.sendMessage("§aResource pack ayarlandı ve yüklendi!");
                }
            }
            case "scoreboard", "sb" -> {
                Realm current = plugin.getRealmManager().getPlayerRealm(player);
                if (current == null || !current.isOwner(player.getUniqueId())) {
                    player.sendMessage("§cSadece kendi realm'inde scoreboard ayarlayabilirsin.");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage("§cKullanım: /realm scoreboard <on|off|title <metin>>");
                    return true;
                }
                switch (args[1].toLowerCase()) {
                    case "on" -> {
                        current.setScoreboardEnabled(true);
                        plugin.getRealmManager().saveAll();
                        plugin.getScoreboardManager().updateAllInRealm(current.getId());
                        player.sendMessage("§aScoreboard açıldı.");
                    }
                    case "off" -> {
                        current.setScoreboardEnabled(false);
                        plugin.getRealmManager().saveAll();
                        plugin.getScoreboardManager().updateAllInRealm(current.getId());
                        player.sendMessage("§aScoreboard kapatıldı.");
                    }
                    case "title" -> {
                        if (args.length < 3) {
                            player.sendMessage("§cKullanım: /realm scoreboard title <metin>");
                            return true;
                        }
                        String title = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                        current.setScoreboardTitle(title.replace("&", "§"));
                        plugin.getRealmManager().saveAll();
                        plugin.getScoreboardManager().updateAllInRealm(current.getId());
                        player.sendMessage("§aScoreboard başlığı güncellendi.");
                    }
                    default -> player.sendMessage("§cKullanım: /realm scoreboard <on|off|title <metin>>");
                }
            }
            case "market" -> {
                if (args.length >= 2 && args[1].equalsIgnoreCase("reload")) {
                    if (!player.hasPermission("realmmc.admin")) {
                        player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));
                        return true;
                    }
                    plugin.getMarketManager().reloadCustom();
                    player.sendMessage("§aMarket eklentileri yenilendi.");
                    return true;
                }
                new io.realmmc.clip.plugin.gui.MarketGUI(plugin).open(player);
            }
            case "delete" -> {
                Realm cur = plugin.getRealmManager().getPlayerRealm(player);
                if (cur == null || !cur.isOwner(player.getUniqueId())) {
                    player.sendMessage("§cSadece kendi realm'ini silebilirsin (içindeyken).");
                    return true;
                }
                String id = cur.getId();
                plugin.getRealmManager().deleteRealm(id);
                player.sendMessage("§aRealm silindi: §e" + id);
            }
            case "admin" -> {
                if (!player.hasPermission("realmmc.admin")) {
                    player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));
                    return true;
                }
                if (args.length >= 2 && args[1].equalsIgnoreCase("delete")) {
                    if (args.length < 3) {
                        player.sendMessage("§cKullanım: /realm admin delete <id>");
                        return true;
                    }
                    plugin.getRealmManager().deleteRealm(args[2]);
                    player.sendMessage("§aRealm silindi: §e" + args[2]);
                    return true;
                }
                new io.realmmc.clip.plugin.gui.AdminGUI(plugin).open(player);
            }
            default -> sendHelp(player);
        }
        return true;
    }

    private boolean isWorldType(String s) {
        return s.equalsIgnoreCase("NORMAL") || s.equalsIgnoreCase("FLAT") ||
                s.equalsIgnoreCase("AMPLIFIED") || s.equalsIgnoreCase("LARGE_BIOMES");
    }

    private void sendHelp(Player player) {
        player.sendMessage("§e§lRealmMC Komutları:");
        player.sendMessage("§a/realm create <isim> [tip] §7- Realm oluştur (NORMAL/FLAT/AMPLIFIED)");
        player.sendMessage("§a/realm join <id> §7- Realm'e katıl");
        player.sendMessage("§a/realm leave §7- Realm'den ayrıl");
        player.sendMessage("§a/realm list §7- Tüm realm'leri listele");
        player.sendMessage("§a/realm info §7- Realm bilgisi");
        player.sendMessage("§a/realm gui §7- Menü");
        player.sendMessage("§a/realm setspawn §7- Spawn ayarla");
        player.sendMessage("§a/realm schem <dosya|url <link>> §7- Schematic yükle");
        player.sendMessage("§a/realm pack <url|clear> §7- Resource pack ayarla");
        player.sendMessage("§a/realm scoreboard <on|off|title> §7- Skor tablosu");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return Arrays.asList("create", "join", "leave", "list", "info", "gui", "setspawn", "schem", "pack", "scoreboard", "market", "delete", "admin")
                    .stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("join")) {
            return plugin.getRealmManager().getAllRealms().stream()
                    .map(Realm::getId)
                    .filter(id -> id.startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("schem")) {
            return Arrays.asList("url").stream().filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("scoreboard")) {
            return Arrays.asList("on", "off", "title").stream().filter(s -> s.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("create")) {
            return Arrays.asList("NORMAL", "FLAT", "AMPLIFIED", "LARGE_BIOMES")
                    .stream().filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}
