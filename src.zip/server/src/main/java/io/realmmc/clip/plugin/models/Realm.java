package io.realmmc.clip.plugin.models;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class Realm implements ConfigurationSerializable {

    private final String id;
    private final UUID owner;
    private String name;
    private String worldName;
    private final Map<UUID, String> members;
    private boolean publicRealm;
    private String icon;
    private String resourcePackUrl;
    private String worldType;
    private boolean scoreboardEnabled;
    private String scoreboardTitle;

    // Spawn stored as primitives so we don't depend on world being loaded at deserialize time
    private String spawnWorld;
    private double spawnX, spawnY, spawnZ;
    private float spawnYaw, spawnPitch;
    private boolean hasSpawn;

    public Realm(String id, UUID owner, String name, String worldName) {
        this.id = id;
        this.owner = owner;
        this.name = name;
        this.worldName = worldName;
        this.members = new HashMap<>();
        this.members.put(owner, "owner");
        this.publicRealm = false;
        this.icon = "MUSHROOM_STEW";
        this.resourcePackUrl = null;
        this.worldType = "NORMAL";
        this.scoreboardEnabled = true;
        this.scoreboardTitle = "§e§l" + name;
        this.hasSpawn = false;
    }

    @SuppressWarnings("unchecked")
    public Realm(Map<String, Object> map) {
        this.id = (String) map.get("id");
        this.owner = UUID.fromString((String) map.get("owner"));
        this.name = (String) map.get("name");
        this.worldName = (String) map.get("worldName");
        this.publicRealm = (Boolean) map.getOrDefault("public", false);
        this.icon = (String) map.getOrDefault("icon", "MUSHROOM_STEW");
        this.resourcePackUrl = (String) map.getOrDefault("resourcePackUrl", null);
        this.worldType = (String) map.getOrDefault("worldType", "NORMAL");
        this.scoreboardEnabled = (Boolean) map.getOrDefault("scoreboardEnabled", true);
        this.scoreboardTitle = (String) map.getOrDefault("scoreboardTitle", "§e§l" + name);

        this.members = new HashMap<>();
        Object raw = map.getOrDefault("members", new HashMap<>());
        if (raw instanceof Map) {
            Map<String, String> rawMembers = (Map<String, String>) raw;
            for (Map.Entry<String, String> e : rawMembers.entrySet()) {
                try {
                    this.members.put(UUID.fromString(e.getKey()), e.getValue());
                } catch (Exception ignored) {}
            }
        }

        // Owner her zaman members içinde owner rank ile dursun
        this.members.put(this.owner, "owner");

        // Safe spawn load (no Location.deserialize)
        if (map.containsKey("spawnX")) {
            this.spawnWorld = (String) map.getOrDefault("spawnWorld", worldName);
            this.spawnX = ((Number) map.get("spawnX")).doubleValue();
            this.spawnY = ((Number) map.get("spawnY")).doubleValue();
            this.spawnZ = ((Number) map.get("spawnZ")).doubleValue();
            this.spawnYaw = map.containsKey("spawnYaw") ? ((Number) map.get("spawnYaw")).floatValue() : 0f;
            this.spawnPitch = map.containsKey("spawnPitch") ? ((Number) map.get("spawnPitch")).floatValue() : 0f;
            this.hasSpawn = true;
        } else {
            this.hasSpawn = false;
        }
    }

    @Override
    public @NotNull Map<String, Object> serialize() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", id);
        map.put("owner", owner.toString());
        map.put("name", name);
        map.put("worldName", worldName);
        map.put("public", publicRealm);
        map.put("icon", icon);
        map.put("resourcePackUrl", resourcePackUrl);
        map.put("worldType", worldType);
        map.put("scoreboardEnabled", scoreboardEnabled);
        map.put("scoreboardTitle", scoreboardTitle);

        Map<String, String> rawMembers = new HashMap<>();
        for (Map.Entry<UUID, String> e : members.entrySet()) {
            rawMembers.put(e.getKey().toString(), e.getValue());
        }
        map.put("members", rawMembers);

        if (hasSpawn) {
            map.put("spawnWorld", spawnWorld != null ? spawnWorld : worldName);
            map.put("spawnX", spawnX);
            map.put("spawnY", spawnY);
            map.put("spawnZ", spawnZ);
            map.put("spawnYaw", spawnYaw);
            map.put("spawnPitch", spawnPitch);
        }
        return map;
    }

    public String getId() { return id; }
    public UUID getOwner() { return owner; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getWorldName() { return worldName; }
    public World getWorld() { return Bukkit.getWorld(worldName); }

    public Location getSpawn() {
        if (hasSpawn) {
            World w = Bukkit.getWorld(spawnWorld != null ? spawnWorld : worldName);
            if (w != null) {
                return new Location(w, spawnX, spawnY, spawnZ, spawnYaw, spawnPitch);
            }
        }
        World w = getWorld();
        return w != null ? w.getSpawnLocation() : null;
    }

    public void setSpawn(Location loc) {
        if (loc == null || loc.getWorld() == null) {
            hasSpawn = false;
            return;
        }
        this.spawnWorld = loc.getWorld().getName();
        this.spawnX = loc.getX();
        this.spawnY = loc.getY();
        this.spawnZ = loc.getZ();
        this.spawnYaw = loc.getYaw();
        this.spawnPitch = loc.getPitch();
        this.hasSpawn = true;
    }

    public Map<UUID, String> getMembers() { return members; }
    public String getRank(UUID uuid) { return members.getOrDefault(uuid, "visitor"); }
    public void setRank(UUID uuid, String rank) { members.put(uuid, rank); }
    public void removeMember(UUID uuid) { members.remove(uuid); }

    public boolean isPublic() { return publicRealm; }
    public void setPublic(boolean publicRealm) { this.publicRealm = publicRealm; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getResourcePackUrl() { return resourcePackUrl; }
    public void setResourcePackUrl(String resourcePackUrl) { this.resourcePackUrl = resourcePackUrl; }

    public String getWorldType() { return worldType; }
    public void setWorldType(String worldType) { this.worldType = worldType; }

    public boolean isScoreboardEnabled() { return scoreboardEnabled; }
    public void setScoreboardEnabled(boolean scoreboardEnabled) { this.scoreboardEnabled = scoreboardEnabled; }

    public String getScoreboardTitle() { return scoreboardTitle; }
    public void setScoreboardTitle(String scoreboardTitle) { this.scoreboardTitle = scoreboardTitle; }

    public boolean isMember(UUID uuid) { return members.containsKey(uuid); }
    public boolean isOwner(UUID uuid) { return owner.equals(uuid); }
}
