package io.realmmc.clip.plugin.listeners;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.gui.AdminGUI;
import io.realmmc.clip.plugin.gui.MarketGUI;
import io.realmmc.clip.plugin.gui.RealmGUI;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener implements Listener {

    private final RealmMC plugin;

    public PlayerListener(RealmMC plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            // Realm dünyasındaysa yetkiyi (owner/member) geri yükle
            plugin.getRealmManager().restoreSession(event.getPlayer());
            plugin.getRealmManager().updateVisibility(event.getPlayer());
        }, 10L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // tracking cleanup optional
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        if (!plugin.getConfigManager().isChatIsolated()) return;

        Player player = event.getPlayer();
        Realm realm = plugin.getRealmManager().getPlayerRealm(player);
        String myRealmId = realm != null ? realm.getId() : null;

        event.getRecipients().removeIf(recipient -> {
            Realm otherRealm = plugin.getRealmManager().getPlayerRealm(recipient);
            String otherId = otherRealm != null ? otherRealm.getId() : null;
            if (myRealmId == null && otherId == null) return false;
            if (myRealmId != null && myRealmId.equals(otherId)) return false;
            return true;
        });
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getCurrentItem() == null) return;

        String title = event.getView().getTitle();
        if (!title.contains("RealmMC") && !title.contains("Realm") && !title.contains("Benim Realm") && !title.contains("Admin") && !title.contains("Plugin Market")) {
            return;
        }

        event.setCancelled(true);

        // === Ana Menü ===
        if (title.contains("RealmMC Menü")) {
            switch (event.getSlot()) {
                case 11 -> {
                    player.closeInventory();
                    player.sendMessage("§eRealm oluşturmak için: §a/realm create <isim> [FLAT|NORMAL|AMPLIFIED]");
                }
                case 13 -> new RealmGUI(plugin).openMyRealms(player);
                case 15 -> {
                    player.closeInventory();
                    player.performCommand("realm list");
                }
                case 22 -> {
                    Realm current = plugin.getRealmManager().getPlayerRealm(player);
                    if (current != null) {
                        new RealmGUI(plugin).openRealmSettings(player, current);
                    }
                }
                case 26 -> player.closeInventory();
            }
        }
        // === Benim Realm'lerim ===
        else if (title.contains("Benim Realm'lerim")) {
            if (event.getSlot() == 49) {
                new RealmGUI(plugin).openMain(player);
                return;
            }
            if (event.getCurrentItem().getItemMeta() != null) {
                String name = event.getCurrentItem().getItemMeta().getDisplayName().replace("§a", "");
                for (Realm r : plugin.getRealmManager().getPlayerOwnedRealms(player.getUniqueId())) {
                    if (r.getName().equals(name)) {
                        player.closeInventory();
                        plugin.getRealmManager().joinRealm(player, r.getId());
                        return;
                    }
                }
            }
        }
        // === Realm Ayarları ===
        else if (title.contains("Realm Ayarları")) {
            Realm current = plugin.getRealmManager().getPlayerRealm(player);
            if (current == null) {
                player.closeInventory();
                return;
            }
            if (!current.isOwner(player.getUniqueId()) && !current.getRank(player.getUniqueId()).equals("admin")) {
                player.sendMessage("§cBu ayarları sadece owner/admin değiştirebilir.");
                player.closeInventory();
                return;
            }

            switch (event.getSlot()) {
                case 10 -> { // Spawn
                    current.setSpawn(player.getLocation());
                    plugin.getRealmManager().saveAll();
                    player.sendMessage("§aSpawn başarıyla ayarlandı!");
                    new RealmGUI(plugin).openRealmSettings(player, current);
                }
                case 12 -> { // Public toggle
                    current.setPublic(!current.isPublic());
                    plugin.getRealmManager().saveAll();
                    player.sendMessage("§aPublic: " + (current.isPublic() ? "§aAçık" : "§cKapalı"));
                    new RealmGUI(plugin).openRealmSettings(player, current);
                }
                case 14 -> { // Resource pack clear
                    if (current.getResourcePackUrl() != null) {
                        current.setResourcePackUrl(null);
                        plugin.getRealmManager().saveAll();
                        player.sendMessage("§aResource pack kaldırıldı. Yeni eklemek için: §e/realm pack <url>");
                    } else {
                        player.sendMessage("§eResource pack eklemek için: §a/realm pack <url>");
                    }
                    new RealmGUI(plugin).openRealmSettings(player, current);
                }
                case 16 -> { // Scoreboard toggle
                    current.setScoreboardEnabled(!current.isScoreboardEnabled());
                    plugin.getRealmManager().saveAll();
                    plugin.getScoreboardManager().updateAllInRealm(current.getId());
                    player.sendMessage("§aScoreboard: " + (current.isScoreboardEnabled() ? "§aAçık" : "§cKapalı"));
                    new RealmGUI(plugin).openRealmSettings(player, current);
                }
                case 19 -> {
                    player.sendMessage("§eÜye yönetimi yakında. Şimdilik rank için komut kullan.");
                }
                case 28 -> { // Market
                    new MarketGUI(plugin).open(player);
                }
                case 25 -> { // Delete
                    player.closeInventory();
                    player.sendMessage("§cRealm silmek için onay: §e/realm admin delete " + current.getId());
                    player.sendMessage("§7(Owner isen admin yetkisi de gerekir veya sonra eklenecek)");
                }
                case 40 -> new RealmGUI(plugin).openMain(player);
            }
        }

        // === Plugin Market ===
        else if (title.contains("Plugin Market")) {
            if (event.getSlot() == 49) {
                Realm cur = plugin.getRealmManager().getPlayerRealm(player);
                if (cur != null) new RealmGUI(plugin).openRealmSettings(player, cur);
                else player.closeInventory();
                return;
            }
            if (event.getSlot() == 45) return;

            Realm realm = plugin.getRealmManager().getPlayerRealm(player);
            if (realm == null) {
                player.closeInventory();
                return;
            }
            org.bukkit.inventory.ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            String display = clicked.getItemMeta().getDisplayName().replace("§a", "").replace("§7", "");
            for (io.realmmc.clip.plugin.market.MarketPlugin mp : plugin.getMarketManager().getAll()) {
                if (mp.getName().equals(display)) {
                    plugin.getMarketManager().toggle(realm.getId(), mp.getId());
                    boolean on = plugin.getMarketManager().isEnabled(realm.getId(), mp.getId());
                    player.sendMessage((on ? "§aKuruldu: " : "§cKaldırıldı: ") + "§e" + mp.getName());
                    new MarketGUI(plugin).open(player);
                    return;
                }
            }
        }

        // === Admin Menü ===
        else if (title.contains("Admin Menü") || title.contains("RealmMC Admin")) {
            switch (event.getSlot()) {
                case 19 -> new AdminGUI(plugin).openRealmList(player);
                case 21 -> {
                    plugin.getConfigManager().load();
                    plugin.getRankManager().load();
                    player.sendMessage("§aConfig ve rank'ler yenilendi.");
                    player.closeInventory();
                }
                case 23 -> {
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (plugin.getRealmManager().getPlayerRealm(p) != null) {
                            plugin.getRealmManager().leaveRealm(p);
                        }
                    }
                    player.sendMessage("§aTüm oyuncular ana sunucuya atıldı.");
                    player.closeInventory();
                }
                case 25 -> {
                    player.closeInventory();
                    player.sendMessage("§eRealm silmek için: §a/realm admin delete <id>");
                }
                case 49 -> player.closeInventory();
            }
        } else if (title.contains("Admin - Tüm Realm")) {
            if (event.getSlot() == 49) {
                new AdminGUI(plugin).open(player);
            }
        }
    }
}
