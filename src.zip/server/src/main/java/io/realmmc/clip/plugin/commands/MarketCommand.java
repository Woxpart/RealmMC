package io.realmmc.clip.plugin.commands;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.listeners.MarketFeatureListener;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;

public class MarketCommand implements CommandExecutor, TabCompleter {

    private final RealmMC plugin;

    public MarketCommand(RealmMC plugin) {
        this.plugin = plugin;
    }

    private boolean requirePlugin(Player player, String pluginId) {
        Realm realm = plugin.getRealmManager().getPlayerRealm(player);
        if (realm == null) {
            player.sendMessage("§cBu komut sadece bir realm içinde kullanılabilir!");
            return false;
        }
        if (!plugin.getMarketManager().isEnabled(realm.getId(), pluginId)) {
            player.sendMessage("§cBu eklenti bu realm'de kurulu değil! §e/realm market");
            return false;
        }
        return true;
    }

    private MarketFeatureListener features() {
        // Get from registered listeners - simpler: store ref on plugin later
        // For now use a static accessor pattern via plugin field
        return MarketFeatureListener.getInstance();
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Sadece oyuncular.");
            return true;
        }

        String cmd = command.getName().toLowerCase();

        switch (cmd) {
            case "balance", "bal", "para" -> {
                if (!requirePlugin(player, "economy")) return true;
                double bal = features().getBalance(player.getUniqueId());
                player.sendMessage("§aBakiyen: §e" + String.format("%.2f", bal) + " coin");
            }
            case "pay" -> {
                if (!requirePlugin(player, "economy")) return true;
                if (args.length < 2) {
                    player.sendMessage("§cKullanım: /pay <oyuncu> <miktar>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage("§cOyuncu bulunamadı.");
                    return true;
                }
                double amount;
                try {
                    amount = Double.parseDouble(args[1]);
                } catch (NumberFormatException e) {
                    player.sendMessage("§cGeçersiz miktar.");
                    return true;
                }
                if (amount <= 0) {
                    player.sendMessage("§cMiktar 0'dan büyük olmalı.");
                    return true;
                }
                double bal = features().getBalance(player.getUniqueId());
                if (bal < amount) {
                    player.sendMessage("§cYetersiz bakiye!");
                    return true;
                }
                features().setBalance(player.getUniqueId(), bal - amount);
                features().setBalance(target.getUniqueId(), features().getBalance(target.getUniqueId()) + amount);
                player.sendMessage("§a" + target.getName() + " adlı oyuncuya §e" + amount + " coin §agönderildi.");
                target.sendMessage("§a" + player.getName() + " sana §e" + amount + " coin §agönderdi.");
            }
            case "eco" -> {
                if (!requirePlugin(player, "economy")) return true;
                if (!player.hasPermission("realmmc.eco.admin") && !isRealmOwner(player)) {
                    player.sendMessage("§cYetkin yok.");
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage("§cKullanım: /eco <give|take|set> <oyuncu> <miktar>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    player.sendMessage("§cOyuncu bulunamadı.");
                    return true;
                }
                double amount;
                try {
                    amount = Double.parseDouble(args[2]);
                } catch (NumberFormatException e) {
                    player.sendMessage("§cGeçersiz miktar.");
                    return true;
                }
                switch (args[0].toLowerCase()) {
                    case "give" -> {
                        features().setBalance(target.getUniqueId(), features().getBalance(target.getUniqueId()) + amount);
                        player.sendMessage("§a" + target.getName() + " bakiyesine §e+" + amount + " §aeklendi.");
                    }
                    case "take" -> {
                        features().setBalance(target.getUniqueId(), Math.max(0, features().getBalance(target.getUniqueId()) - amount));
                        player.sendMessage("§a" + target.getName() + " bakiyesinden §e-" + amount + " §aeksiltildi.");
                    }
                    case "set" -> {
                        features().setBalance(target.getUniqueId(), amount);
                        player.sendMessage("§a" + target.getName() + " bakiyesi §e" + amount + " §ayapıldı.");
                    }
                    default -> player.sendMessage("§cKullanım: /eco <give|take|set> <oyuncu> <miktar>");
                }
            }
            case "setwarp" -> {
                if (!requirePlugin(player, "warps")) return true;
                if (!isRealmStaff(player)) {
                    player.sendMessage("§cSadece owner/admin warp koyabilir.");
                    return true;
                }
                if (args.length < 1) {
                    player.sendMessage("§cKullanım: /setwarp <isim>");
                    return true;
                }
                Realm realm = plugin.getRealmManager().getPlayerRealm(player);
                Location loc = player.getLocation();
                String data = loc.getX() + "," + loc.getY() + "," + loc.getZ() + "," + loc.getYaw() + "," + loc.getPitch();
                features().getWarps(realm.getId()).put(args[0].toLowerCase(), data);
                player.sendMessage("§aWarp ayarlandı: §e" + args[0]);
            }
            case "warp" -> {
                if (!requirePlugin(player, "warps")) return true;
                if (args.length < 1) {
                    player.sendMessage("§cKullanım: /warp <isim>");
                    player.sendMessage("§7Liste: /warps");
                    return true;
                }
                Realm realm = plugin.getRealmManager().getPlayerRealm(player);
                String data = features().getWarps(realm.getId()).get(args[0].toLowerCase());
                if (data == null) {
                    player.sendMessage("§cWarp bulunamadı: §e" + args[0]);
                    return true;
                }
                String[] p = data.split(",");
                Location loc = new Location(player.getWorld(),
                        Double.parseDouble(p[0]), Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                        Float.parseFloat(p[3]), Float.parseFloat(p[4]));
                player.teleport(loc);
                player.sendMessage("§aIşınlandın: §e" + args[0]);
            }
            case "delwarp" -> {
                if (!requirePlugin(player, "warps")) return true;
                if (!isRealmStaff(player)) {
                    player.sendMessage("§cSadece owner/admin warp silebilir.");
                    return true;
                }
                if (args.length < 1) {
                    player.sendMessage("§cKullanım: /delwarp <isim>");
                    return true;
                }
                Realm realm = plugin.getRealmManager().getPlayerRealm(player);
                if (features().getWarps(realm.getId()).remove(args[0].toLowerCase()) != null) {
                    player.sendMessage("§aWarp silindi: §e" + args[0]);
                } else {
                    player.sendMessage("§cWarp bulunamadı.");
                }
            }
            case "warps" -> {
                if (!requirePlugin(player, "warps")) return true;
                Realm realm = plugin.getRealmManager().getPlayerRealm(player);
                Set<String> names = features().getWarps(realm.getId()).keySet();
                if (names.isEmpty()) {
                    player.sendMessage("§eHiç warp yok.");
                } else {
                    player.sendMessage("§aWarplar: §e" + String.join("§7, §e", names));
                }
            }
            default -> player.sendMessage("§cBilinmeyen komut.");
        }
        return true;
    }

    private boolean isRealmOwner(Player player) {
        Realm r = plugin.getRealmManager().getPlayerRealm(player);
        return r != null && r.isOwner(player.getUniqueId());
    }

    private boolean isRealmStaff(Player player) {
        Realm r = plugin.getRealmManager().getPlayerRealm(player);
        if (r == null) return false;
        String rank = r.getRank(player.getUniqueId());
        return rank.equals("owner") || rank.equals("admin");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        String cmd = command.getName().toLowerCase();
        if (!(sender instanceof Player player)) return List.of();

        if (cmd.equals("pay") || cmd.equals("eco")) {
            if (args.length == 1 && cmd.equals("eco")) {
                return List.of("give", "take", "set").stream()
                        .filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
            }
            int playerArg = cmd.equals("eco") ? 2 : 1;
            if (args.length == playerArg) {
                return Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(n -> n.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                        .collect(Collectors.toList());
            }
        }
        if ((cmd.equals("warp") || cmd.equals("delwarp")) && args.length == 1) {
            Realm realm = plugin.getRealmManager().getPlayerRealm(player);
            if (realm != null) {
                return features().getWarps(realm.getId()).keySet().stream()
                        .filter(n -> n.startsWith(args[0].toLowerCase()))
                        .collect(Collectors.toList());
            }
        }
        return List.of();
    }
}
