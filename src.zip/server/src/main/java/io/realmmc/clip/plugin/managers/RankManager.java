package io.realmmc.clip.plugin.managers;

import io.realmmc.clip.plugin.RealmMC;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

public class RankManager {

    private final RealmMC plugin;
    private final Map<String, RankData> ranks = new LinkedHashMap<>();

    public RankManager(RealmMC plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        ranks.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("ranks");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            String display = section.getString(key + ".display", key);
            int priority = section.getInt(key + ".priority", 0);
            List<String> perms = section.getStringList(key + ".permissions");
            ranks.put(key.toLowerCase(), new RankData(key.toLowerCase(), display, priority, perms));
        }
    }

    public RankData getRank(String name) {
        return ranks.get(name.toLowerCase());
    }

    public Collection<RankData> getAllRanks() {
        return ranks.values();
    }

    public boolean hasPermission(String rankName, String permission) {
        RankData rank = getRank(rankName);
        if (rank == null) return false;
        return rank.permissions().contains(permission) || rank.permissions().contains("*");
    }

    public record RankData(String name, String display, int priority, List<String> permissions) {}
}
