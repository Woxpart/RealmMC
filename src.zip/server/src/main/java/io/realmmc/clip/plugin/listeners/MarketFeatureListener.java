package io.realmmc.clip.plugin.listeners;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MarketFeatureListener implements Listener {

    private static MarketFeatureListener instance;
    private final RealmMC plugin;
    // Simple economy: uuid -> balance (global for demo, could be per-realm)
    private final Map<UUID, Double> balances = new HashMap<>();
    // Simple warps: realmId -> (warpName -> "x,y,z")
    private final Map<String, Map<String, String>> warps = new HashMap<>();

    public MarketFeatureListener(RealmMC plugin) {
        this.plugin = plugin;
        instance = this;
    }

    public static MarketFeatureListener getInstance() {
        return instance;
    }

    private boolean enabled(Player player, String pluginId) {
        Realm r = plugin.getRealmManager().getPlayerRealm(player);
        if (r == null) return false;
        return plugin.getMarketManager().isEnabled(r.getId(), pluginId);
    }

    // === PROTECT ===
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player p = event.getPlayer();
        if (!enabled(p, "protect")) return;
        if (p.getGameMode() == GameMode.CREATIVE) return;
        Realm r = plugin.getRealmManager().getPlayerRealm(p);
        if (r == null) return;
        String rank = r.getRank(p.getUniqueId());
        if (rank.equals("visitor")) {
            event.setCancelled(true);
            p.sendMessage("§cBu realm'de kırma iznin yok! (Protect eklentisi)");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        Player p = event.getPlayer();
        if (!enabled(p, "protect")) return;
        if (p.getGameMode() == GameMode.CREATIVE) return;
        Realm r = plugin.getRealmManager().getPlayerRealm(p);
        if (r == null) return;
        String rank = r.getRank(p.getUniqueId());
        if (rank.equals("visitor")) {
            event.setCancelled(true);
            p.sendMessage("§cBu realm'de yerleştirme iznin yok! (Protect eklentisi)");
        }
    }

    // === WELCOME ===
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player p = event.getPlayer();
        Realm r = plugin.getRealmManager().getPlayerRealm(p);
        if (r == null) return;
        if (!plugin.getMarketManager().isEnabled(r.getId(), "welcome")) return;
        p.sendMessage("§a§lHoş geldin §e" + p.getName() + "§a! §7Realm: §f" + r.getName());
        p.sendMessage("§7Rankın: §e" + r.getRank(p.getUniqueId()));
    }

    // === CHAT FORMAT ===
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player p = event.getPlayer();
        if (!enabled(p, "chatformat")) return;
        Realm r = plugin.getRealmManager().getPlayerRealm(p);
        if (r == null) return;
        String rank = r.getRank(p.getUniqueId());
        String prefix = switch (rank) {
            case "owner" -> "§c[Kurucu] ";
            case "admin" -> "§4[Admin] ";
            case "member" -> "§a[Üye] ";
            default -> "§7[Ziyaretçi] ";
        };
        event.setFormat(prefix + "§f%1$s§7: §f%2$s");
    }

    // Economy / warps helpers used by commands later
    public double getBalance(UUID uuid) {
        return balances.getOrDefault(uuid, 100.0);
    }

    public void setBalance(UUID uuid, double amount) {
        balances.put(uuid, amount);
    }

    public Map<String, String> getWarps(String realmId) {
        return warps.computeIfAbsent(realmId, k -> new HashMap<>());
    }
}
