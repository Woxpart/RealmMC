package io.realmmc.clip.plugin;

import io.realmmc.clip.plugin.commands.RealmCommand;
import io.realmmc.clip.plugin.commands.MarketCommand;
import io.realmmc.clip.plugin.listeners.PlayerListener;
import io.realmmc.clip.plugin.listeners.MarketFeatureListener;
import io.realmmc.clip.plugin.managers.ConfigManager;
import io.realmmc.clip.plugin.managers.RealmManager;
import io.realmmc.clip.plugin.managers.RankManager;
import io.realmmc.clip.plugin.managers.ResourcePackManager;
import io.realmmc.clip.plugin.managers.SchematicManager;
import io.realmmc.clip.plugin.managers.ScoreboardManager;
import io.realmmc.clip.plugin.market.MarketManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class RealmMC extends JavaPlugin {

    private static RealmMC instance;
    private ConfigManager configManager;
    private RealmManager realmManager;
    private RankManager rankManager;
    private SchematicManager schematicManager;
    private ScoreboardManager scoreboardManager;
    private ResourcePackManager resourcePackManager;
    private MarketManager marketManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        // extract default market ymls
        for (String id : new String[]{"economy", "warps", "protect", "chatformat", "welcome"}) {
            saveResource("market/" + id + ".yml", false);
        }

        this.configManager = new ConfigManager(this);
        this.configManager.load();

        this.rankManager = new RankManager(this);
        this.realmManager = new RealmManager(this);
        this.schematicManager = new SchematicManager(this);
        this.scoreboardManager = new ScoreboardManager(this);
        this.resourcePackManager = new ResourcePackManager(this);
        this.marketManager = new MarketManager(this);

        getCommand("realm").setExecutor(new RealmCommand(this));
        getCommand("realm").setTabCompleter(new RealmCommand(this));

        MarketCommand marketCmd = new MarketCommand(this);
        for (String cmd : new String[]{"balance", "pay", "eco", "setwarp", "warp", "delwarp", "warps"}) {
            if (getCommand(cmd) != null) {
                getCommand(cmd).setExecutor(marketCmd);
                getCommand(cmd).setTabCompleter(marketCmd);
            }
        }

        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new MarketFeatureListener(this), this);

        getLogger().info("RealmMC v" + getDescription().getVersion() + " enabled! (Folia supported)");
    }

    @Override
    public void onDisable() {
        if (realmManager != null) realmManager.saveAll();
        if (marketManager != null) marketManager.saveEnabledState();
        getLogger().info("RealmMC disabled.");
    }

    public static RealmMC getInstance() { return instance; }
    public ConfigManager getConfigManager() { return configManager; }
    public RealmManager getRealmManager() { return realmManager; }
    public RankManager getRankManager() { return rankManager; }
    public SchematicManager getSchematicManager() { return schematicManager; }
    public ScoreboardManager getScoreboardManager() { return scoreboardManager; }
    public ResourcePackManager getResourcePackManager() { return resourcePackManager; }
    public MarketManager getMarketManager() { return marketManager; }
}
