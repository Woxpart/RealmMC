package io.realmmc.clip.plugin.gui;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.models.Realm;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class AdminGUI {

    private final RealmMC plugin;

    public AdminGUI(RealmMC plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
                Component.text("RealmMC Admin Menü", NamedTextColor.RED, TextDecoration.BOLD));

        // Stats
        inv.setItem(4, item(Material.NETHER_STAR, "§c§lSunucu İstatistik",
                "§7Toplam Realm: §f" + plugin.getRealmManager().getAllRealms().size(),
                "§7Online Oyuncu: §f" + Bukkit.getOnlinePlayers().size()));

        // List all realms
        inv.setItem(19, item(Material.BOOK, "§e§lTüm Realm'ler",
                "§7Tüm realm'leri listele ve yönet"));

        // Reload
        inv.setItem(21, item(Material.EMERALD, "§a§lConfig Yenile",
                "§7config.yml ve rank'leri yeniden yükle"));

        // Force leave all
        inv.setItem(23, item(Material.BARRIER, "§c§lHerkesi Ana Sunucuya At",
                "§7Tüm oyuncuları realm'lerden çıkar"));

        // Delete realm prompt
        inv.setItem(25, item(Material.TNT, "§4§lRealm Sil",
                "§7ID ile realm silmek için chat'e yaz",
                "§e/realm admin delete <id>"));

        // Rank icons info
        inv.setItem(37, item(Material.GOLDEN_HELMET, "§6§lKurucu İkonu",
                "§7Owner rank ikonu aktif",
                "§8icons/owner.png"));

        inv.setItem(39, item(Material.IRON_HELMET, "§7§lOyuncu / Admin İkonu",
                "§7Player & Admin rank ikonu",
                "§8icons/player.png"));

        inv.setItem(49, item(Material.ARROW, "§eKapat", ""));

        player.openInventory(inv);
    }

    public void openRealmList(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
                Component.text("Admin - Tüm Realm'ler", NamedTextColor.RED));

        int slot = 0;
        for (Realm r : plugin.getRealmManager().getAllRealms()) {
            if (slot >= 45) break;
            inv.setItem(slot++, item(Material.MUSHROOM_STEW, "§a" + r.getName(),
                    "§7ID: §f" + r.getId(),
                    "§7Owner: §f" + r.getOwner().toString().substring(0, 8) + "...",
                    "§7Üye: §f" + r.getMembers().size(),
                    "§7Tip: §f" + r.getWorldType(),
                    "§eSol tık: Bilgi | Sağ tık: Sil (yakında)"));
        }

        inv.setItem(49, item(Material.ARROW, "§eGeri", ""));
        player.openInventory(inv);
    }

    private ItemStack item(Material mat, String name, String... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        List<String> lore = new ArrayList<>();
        for (String line : loreLines) {
            if (!line.isEmpty()) lore.add(line);
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
