package io.realmmc.clip.plugin.managers;

import io.realmmc.clip.plugin.RealmMC;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {

    private final RealmMC plugin;
    private FileConfiguration config;

    public ConfigManager(RealmMC plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.reloadConfig();
        this.config = plugin.getConfig();
    }

    public String getMessage(String key) {
        String msg = config.getString("messages." + key, key);
        return color(getPrefix() + msg);
    }

    public String getMessage(String key, String... replacements) {
        String msg = getMessage(key);
        for (int i = 0; i < replacements.length; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        return msg;
    }

    public String getPrefix() {
        return color(config.getString("messages.prefix", "&e&lRealmMC &7» "));
    }

    public int getMaxRealmsPerPlayer() {
        return config.getInt("settings.max-realms-per-player", 3);
    }

    public boolean isChatIsolated() {
        return config.getBoolean("settings.isolation.chat", true);
    }

    public boolean isTablistIsolated() {
        return config.getBoolean("settings.isolation.tablist", true);
    }

    public String getTransferMessage(String realmName) {
        return color(config.getString("settings.transfer-message", "&e&lRealmMC &7» &fBağlanılıyor: &a%realm%")
                .replace("%realm%", realmName));
    }

    public String getLeaveMessage() {
        return color(config.getString("settings.leave-message", "&e&lRealmMC &7» &fAna sunucuya dönüldü."));
    }

    public static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
