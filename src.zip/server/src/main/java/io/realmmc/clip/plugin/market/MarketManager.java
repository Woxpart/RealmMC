package io.realmmc.clip.plugin.market;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MarketManager {

    private final RealmMC plugin;
    private final Map<String, MarketPlugin> available = new LinkedHashMap<>();
    // realmId -> set of enabled plugin ids
    private final Map<String, Set<String>> enabled = new HashMap<>();

    public MarketManager(RealmMC plugin) {
        this.plugin = plugin;
        loadBuiltins();
        loadCustom();
        loadEnabledState();
    }

    private void loadBuiltins() {
        String[] ids = {"economy", "warps", "protect", "chatformat", "welcome"};
        for (String id : ids) {
            try (InputStream in = plugin.getResource("market/" + id + ".yml")) {
                if (in == null) continue;
                YamlConfiguration yaml = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
                registerFromYaml(yaml, true);
            } catch (Exception e) {
                plugin.getLogger().warning("Builtin market plugin load fail: " + id);
            }
        }
        plugin.getLogger().info("Market: " + available.size() + " eklenti yüklendi.");
    }

    private void loadCustom() {
        File folder = new File(plugin.getDataFolder(), "market");
        if (!folder.exists()) folder.mkdirs();
        File[] files = folder.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return;
        for (File f : files) {
            try {
                YamlConfiguration yaml = YamlConfiguration.loadConfiguration(f);
                registerFromYaml(yaml, false);
            } catch (Exception e) {
                plugin.getLogger().warning("Custom market plugin fail: " + f.getName());
            }
        }
    }

    private void registerFromYaml(YamlConfiguration yaml, boolean builtin) {
        String id = yaml.getString("id");
        if (id == null || available.containsKey(id)) return;
        String name = yaml.getString("name", id);
        String desc = yaml.getString("description", "");
        String version = yaml.getString("version", "1.0");
        String author = yaml.getString("author", "Unknown");
        Material icon = Material.BOOK;
        try {
            icon = Material.valueOf(yaml.getString("icon", "BOOK").toUpperCase());
        } catch (Exception ignored) {}
        int price = yaml.getInt("price", 0);
        List<String> cmds = yaml.getStringList("commands");
        available.put(id, new MarketPlugin(id, name, desc, version, author, icon, price, cmds, builtin));
    }

    private void loadEnabledState() {
        File file = new File(plugin.getDataFolder(), "market-enabled.yml");
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        for (String realmId : yaml.getKeys(false)) {
            enabled.put(realmId, new HashSet<>(yaml.getStringList(realmId)));
        }
    }

    public void saveEnabledState() {
        File file = new File(plugin.getDataFolder(), "market-enabled.yml");
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<String, Set<String>> e : enabled.entrySet()) {
            yaml.set(e.getKey(), new ArrayList<>(e.getValue()));
        }
        try {
            yaml.save(file);
        } catch (Exception e) {
            plugin.getLogger().warning("market-enabled.yml kaydedilemedi");
        }
    }

    public Collection<MarketPlugin> getAll() {
        return available.values();
    }

    public MarketPlugin get(String id) {
        return available.get(id);
    }

    public boolean isEnabled(String realmId, String pluginId) {
        return enabled.getOrDefault(realmId, Collections.emptySet()).contains(pluginId);
    }

    public void enable(String realmId, String pluginId) {
        enabled.computeIfAbsent(realmId, k -> new HashSet<>()).add(pluginId);
        saveEnabledState();
    }

    public void disable(String realmId, String pluginId) {
        Set<String> set = enabled.get(realmId);
        if (set != null) {
            set.remove(pluginId);
            saveEnabledState();
        }
    }

    public void toggle(String realmId, String pluginId) {
        if (isEnabled(realmId, pluginId)) disable(realmId, pluginId);
        else enable(realmId, pluginId);
    }

    public Set<String> getEnabled(String realmId) {
        return enabled.getOrDefault(realmId, Collections.emptySet());
    }

    /** Developer: reload custom market plugins from folder */
    public void reloadCustom() {
        // remove non-builtin
        available.entrySet().removeIf(e -> !e.getValue().isBuiltin());
        loadCustom();
    }
}
