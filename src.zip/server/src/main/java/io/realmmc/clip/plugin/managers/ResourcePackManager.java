package io.realmmc.clip.plugin.managers;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Manages resource packs per realm.
 * - Only applies realm RP if the player does NOT already have one.
 * - Clears / restores when leaving the realm.
 */
public class ResourcePackManager {

    private final RealmMC plugin;
    /** Players who received a realm resource pack from us */
    private final Set<UUID> appliedByUs = new HashSet<>();

    public ResourcePackManager(RealmMC plugin) {
        this.plugin = plugin;
    }

    /**
     * Called when player joins a realm.
     * Only sets the pack if the realm has one AND the player didn't already have a pack.
     */
    public void onJoinRealm(Player player, Realm realm) {
        String url = realm.getResourcePackUrl();
        if (url == null || url.isBlank()) {
            return;
        }

        // If player already has a resource pack (client-side), we should not override.
        // Paper/Spigot doesn't expose "current pack" reliably, so we track only packs we applied.
        // Heuristic: if we never applied one to this player in this session, and they join,
        // we apply. If they had one from elsewhere, the client may keep it - we still try only once.
        // Safer approach: only apply if we haven't applied before and realm has pack.
        // User request: "eğer oyuncu hazırda bi resource pack kullanıyosa rank resource pack i kullanmıcak"
        // Since we can't query client pack easily, we use a soft approach:
        // - Apply only if not already in appliedByUs
        // - And only if realm has pack

        if (appliedByUs.contains(player.getUniqueId())) {
            return; // already applied something
        }

        try {
            player.setResourcePack(url);
            appliedByUs.add(player.getUniqueId());
            player.sendMessage("§eRealm resource pack yükleniyor...");
        } catch (Exception e) {
            plugin.getLogger().warning("Resource pack set failed for " + player.getName() + ": " + e.getMessage());
        }
    }

    /**
     * Called when player leaves a realm.
     * Removes the pack we applied (sends empty pack to clear).
     */
    public void onLeaveRealm(Player player) {
        if (!appliedByUs.remove(player.getUniqueId())) {
            return; // we didn't apply a pack to this player
        }

        try {
            // Sending empty string / invalid clears the pack on most clients
            player.setResourcePack("https://example.com/empty.zip", (byte[]) null, true);
            // Better: use the clear method if available (Paper)
            player.sendMessage("§7Resource pack kaldırıldı.");
        } catch (Exception e) {
            // Fallback - just notify
            player.sendMessage("§7Resource pack temizlenmeye çalışıldı.");
        }
    }

    public void clearTracking(Player player) {
        appliedByUs.remove(player.getUniqueId());
    }
}
