package io.realmmc.clip.plugin.managers;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RealmManager {

    private final RealmMC plugin;
    private final Map<String, Realm> realms = new ConcurrentHashMap<>();
    private final Map<UUID, String> playerRealm = new ConcurrentHashMap<>();
    private final File dataFile;
    private FileConfiguration dataConfig;

    public RealmManager(RealmMC plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "realms.yml");
        loadAll();
    }

    public void loadAll() {
        if (!dataFile.exists()) {
            try {
                dataFile.getParentFile().mkdirs();
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create realms.yml");
                return;
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

        if (dataConfig.contains("realms")) {
            for (String key : dataConfig.getConfigurationSection("realms").getKeys(false)) {
                try {
                    // Read values manually to avoid Location.deserialize crash on unknown world
                    org.bukkit.configuration.ConfigurationSection sec = dataConfig.getConfigurationSection("realms." + key);
                    Map<String, Object> map = new java.util.LinkedHashMap<>();
                    for (String k : sec.getKeys(false)) {
                        // Skip old Bukkit Location serialization blocks
                        if (k.equals("spawn") && sec.isConfigurationSection(k)) {
                            continue;
                        }
                        map.put(k, sec.get(k));
                    }
                    // Also support old style if spawn was saved as section with x/y/z
                    if (sec.isConfigurationSection("spawn")) {
                        org.bukkit.configuration.ConfigurationSection spawnSec = sec.getConfigurationSection("spawn");
                        if (spawnSec != null && spawnSec.contains("x")) {
                            map.put("spawnWorld", spawnSec.getString("world", sec.getString("worldName")));
                            map.put("spawnX", spawnSec.getDouble("x"));
                            map.put("spawnY", spawnSec.getDouble("y"));
                            map.put("spawnZ", spawnSec.getDouble("z"));
                            map.put("spawnYaw", (float) spawnSec.getDouble("yaw", 0));
                            map.put("spawnPitch", (float) spawnSec.getDouble("pitch", 0));
                        }
                    }
                    Realm realm = new Realm(map);
                    realms.put(realm.getId(), realm);

                    if (Bukkit.getWorld(realm.getWorldName()) == null) {
                        createWorld(realm.getWorldName(), realm.getWorldType());
                    }
                } catch (Exception e) {
                    plugin.getLogger().warning("Realm yüklenemedi (" + key + "): " + e.getMessage());
                }
            }
        }
        plugin.getLogger().info("Loaded " + realms.size() + " realms.");
    }

    public void saveAll() {
        dataConfig = new YamlConfiguration();
        for (Realm realm : realms.values()) {
            dataConfig.set("realms." + realm.getId(), realm.serialize());
        }
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save realms.yml");
        }
    }

    public Realm createRealm(Player owner, String name) {
        return createRealm(owner, name, "NORMAL");
    }

    public Realm createRealm(Player owner, String name, String worldType) {
        long owned = realms.values().stream()
                .filter(r -> r.getOwner().equals(owner.getUniqueId()))
                .count();

        if (owned >= plugin.getConfigManager().getMaxRealmsPerPlayer()) {
            owner.sendMessage(plugin.getConfigManager().getMessage("max-realms"));
            return null;
        }

        String id = UUID.randomUUID().toString().substring(0, 8);
        String worldName = "realm_" + id;

        World world = createWorld(worldName, worldType);
        if (world == null) {
            owner.sendMessage(ChatColor.RED + "World oluşturulamadı!");
            return null;
        }

        Realm realm = new Realm(id, owner.getUniqueId(), name, worldName);
        realm.setWorldType(worldType);
        realm.setSpawn(world.getSpawnLocation());
        realms.put(id, realm);
        saveAll();

        owner.sendMessage(plugin.getConfigManager().getMessage("realm-created", "%realm%", name));
        owner.sendMessage("§7Dünya tipi: §e" + worldType);
        return realm;
    }

    private World createWorld(String worldName, String typeStr) {
        WorldCreator creator = new WorldCreator(worldName);
        creator.environment(World.Environment.NORMAL);
        creator.generateStructures(false);

        WorldType type = WorldType.NORMAL;
        if (typeStr != null) {
            try {
                type = WorldType.valueOf(typeStr.toUpperCase());
            } catch (IllegalArgumentException ignored) {}
        }
        creator.type(type);

        World world = creator.createWorld();
        if (world != null) {
            world.setSpawnLocation(0, 80, 0);
            world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
            world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, true);
            world.setDifficulty(Difficulty.PEACEFUL);
        }
        return world;
    }

    public boolean joinRealm(Player player, String realmId) {
        Realm realm = realms.get(realmId);
        if (realm == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("realm-not-found"));
            return false;
        }

        if (playerRealm.containsKey(player.getUniqueId())) {
            player.sendMessage(plugin.getConfigManager().getMessage("already-in-realm"));
            return false;
        }

        World world = realm.getWorld();
        if (world == null) {
            world = createWorld(realm.getWorldName(), realm.getWorldType());
            if (world == null) return false;
        }

        player.sendMessage(plugin.getConfigManager().getTransferMessage(realm.getName()));
        player.teleport(realm.getSpawn() != null ? realm.getSpawn() : world.getSpawnLocation());

        playerRealm.put(player.getUniqueId(), realmId);

        // Rank koruma: owner her zaman owner, mevcut üyeler korunur
        if (realm.isOwner(player.getUniqueId())) {
            realm.setRank(player.getUniqueId(), "owner");
        } else if (!realm.isMember(player.getUniqueId())) {
            realm.setRank(player.getUniqueId(), "visitor");
        }
        saveAll();

        // Isolation
        updateVisibility(player);

        // Resource pack (only if player doesn't already have one from us / smart)
        plugin.getResourcePackManager().onJoinRealm(player, realm);

        // Scoreboard
        plugin.getScoreboardManager().applyScoreboard(player);

        player.sendMessage(plugin.getConfigManager().getMessage("realm-joined", "%realm%", realm.getName()));
        return true;
    }

    public void leaveRealm(Player player) {
        String realmId = playerRealm.remove(player.getUniqueId());
        if (realmId == null) {
            player.sendMessage(ChatColor.RED + "Zaten bir realm'de değilsin.");
            return;
        }

        World main = Bukkit.getWorlds().get(0);
        player.teleport(main.getSpawnLocation());

        // Clear resource pack we applied
        plugin.getResourcePackManager().onLeaveRealm(player);

        updateVisibility(player);
        plugin.getScoreboardManager().clearScoreboard(player);

        player.sendMessage(plugin.getConfigManager().getLeaveMessage());
        player.sendMessage(plugin.getConfigManager().getMessage("realm-left"));
    }

    public void updateVisibility(Player player) {
        String myRealmId = playerRealm.get(player.getUniqueId());

        for (Player other : Bukkit.getOnlinePlayers()) {
            if (other.equals(player)) continue;

            String otherRealmId = playerRealm.get(other.getUniqueId());

            boolean sameRealm = (myRealmId == null && otherRealmId == null) ||
                    (myRealmId != null && myRealmId.equals(otherRealmId));

            if (sameRealm) {
                player.showPlayer(plugin, other);
                other.showPlayer(plugin, player);
            } else {
                player.hidePlayer(plugin, other);
                other.hidePlayer(plugin, player);
            }
        }
    }

    public void refreshAllVisibilities() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            updateVisibility(p);
        }
    }

    public Realm getRealm(String id) {
        return realms.get(id);
    }

    public Realm getPlayerRealm(Player player) {
        String id = playerRealm.get(player.getUniqueId());
        return id != null ? realms.get(id) : null;
    }

    public Collection<Realm> getAllRealms() {
        return realms.values();
    }

    public List<Realm> getPlayerOwnedRealms(UUID uuid) {
        List<Realm> list = new ArrayList<>();
        for (Realm r : realms.values()) {
            if (r.getOwner().equals(uuid)) list.add(r);
        }
        return list;
    }

    public void deleteRealm(String id) {
        Realm realm = realms.remove(id);
        if (realm == null) return;

        for (Map.Entry<UUID, String> e : new HashMap<>(playerRealm).entrySet()) {
            if (e.getValue().equals(id)) {
                Player p = Bukkit.getPlayer(e.getKey());
                if (p != null) leaveRealm(p);
            }
        }

        World world = Bukkit.getWorld(realm.getWorldName());
        if (world != null) {
            Bukkit.unloadWorld(world, false);
        }

        saveAll();
    }

    public String getPlayerRealmId(UUID uuid) {
        return playerRealm.get(uuid);
    }

    /** Oyuncu sunucuya girince: eğer bir realm dünyasındaysa session'ı geri yükle */
    public void restoreSession(Player player) {
        String worldName = player.getWorld().getName();
        if (!worldName.startsWith("realm_")) {
            return;
        }
        for (Realm realm : realms.values()) {
            if (realm.getWorldName().equals(worldName)) {
                playerRealm.put(player.getUniqueId(), realm.getId());
                // Rank koru
                if (realm.isOwner(player.getUniqueId())) {
                    realm.setRank(player.getUniqueId(), "owner");
                } else if (!realm.isMember(player.getUniqueId())) {
                    realm.setRank(player.getUniqueId(), "visitor");
                }
                updateVisibility(player);
                plugin.getScoreboardManager().applyScoreboard(player);
                plugin.getResourcePackManager().onJoinRealm(player, realm);
                plugin.getLogger().info(player.getName() + " realm session restore: " + realm.getName() + " rank=" + realm.getRank(player.getUniqueId()));
                return;
            }
        }
    }

    public Realm getRealmByWorld(String worldName) {
        for (Realm r : realms.values()) {
            if (r.getWorldName().equals(worldName)) return r;
        }
        return null;
    }

}
