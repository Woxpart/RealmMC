package io.realmmc.clip.plugin.managers;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.models.Realm;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ScoreboardManager {

    private final RealmMC plugin;
    private final Map<UUID, Scoreboard> playerBoards = new HashMap<>();

    public ScoreboardManager(RealmMC plugin) {
        this.plugin = plugin;
    }

    public void applyScoreboard(Player player) {
        Realm realm = plugin.getRealmManager().getPlayerRealm(player);
        if (realm == null || !realm.isScoreboardEnabled()) {
            clearScoreboard(player);
            return;
        }

        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("realm", Criteria.DUMMY, realm.getScoreboardTitle());
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        int onlineInRealm = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            Realm r = plugin.getRealmManager().getPlayerRealm(p);
            if (r != null && r.getId().equals(realm.getId())) onlineInRealm++;
        }

        obj.getScore("§7").setScore(6);
        obj.getScore("§fRealm: §a" + realm.getName()).setScore(5);
        obj.getScore("§fRank: §e" + realm.getRank(player.getUniqueId())).setScore(4);
        obj.getScore("§fOnline: §b" + onlineInRealm).setScore(3);
        obj.getScore("§8").setScore(2);
        obj.getScore("§eRealmMC").setScore(1);

        player.setScoreboard(board);
        playerBoards.put(player.getUniqueId(), board);
    }

    public void clearScoreboard(Player player) {
        player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        playerBoards.remove(player.getUniqueId());
    }

    public void updateAllInRealm(String realmId) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            Realm r = plugin.getRealmManager().getPlayerRealm(p);
            if (r != null && r.getId().equals(realmId)) {
                applyScoreboard(p);
            }
        }
    }
}
