package io.realmmc.clip.plugin.gui;

import io.realmmc.clip.plugin.RealmMC;
import io.realmmc.clip.plugin.models.Realm;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class RealmGUI {

    private final RealmMC plugin;

    public RealmGUI(RealmMC plugin) {
        this.plugin = plugin;
    }

    public void openMain(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27,
                Component.text("RealmMC Menü", NamedTextColor.GOLD, TextDecoration.BOLD));

        inv.setItem(11, item(Material.EMERALD_BLOCK, "§a§lYeni Realm Oluştur",
                "§7Kendi realm sunucunu oluştur",
                "§eTıkla → isim yazman istenecek"));

        inv.setItem(13, item(Material.CHEST, "§e§lBenim Realm'lerim",
                "§7Sahip olduğun realm'leri yönet"));

        inv.setItem(15, item(Material.COMPASS, "§b§lPublic Realm'ler",
                "§7Herkese açık realm'lere katıl"));

        Realm current = plugin.getRealmManager().getPlayerRealm(player);
        if (current != null && (current.isOwner(player.getUniqueId()) || current.getRank(player.getUniqueId()).equals("admin"))) {
            inv.setItem(22, item(Material.COMPARATOR, "§6§lRealm Ayarları",
                    "§7Spawn, pack, scoreboard, public...",
                    "§eRealm: §f" + current.getName()));
        }

        inv.setItem(26, item(Material.BARRIER, "§cKapat", ""));
        player.openInventory(inv);
    }

    public void openMyRealms(Player player) {
        List<Realm> owned = plugin.getRealmManager().getPlayerOwnedRealms(player.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 54,
                Component.text("Benim Realm'lerim", NamedTextColor.YELLOW));

        int slot = 0;
        for (Realm r : owned) {
            if (slot >= 45) break;
            inv.setItem(slot++, item(Material.MUSHROOM_STEW, "§a" + r.getName(),
                    "§7ID: §f" + r.getId(),
                    "§7Üyeler: §f" + r.getMembers().size(),
                    "§7Tip: §f" + r.getWorldType(),
                    "§eTıkla: Katıl / Yönet"));
        }

        inv.setItem(49, item(Material.ARROW, "§eGeri", ""));
        player.openInventory(inv);
    }

    public void openRealmSettings(Player player, Realm realm) {
        Inventory inv = Bukkit.createInventory(null, 45,
                Component.text("Realm Ayarları: " + realm.getName(), NamedTextColor.GOLD));

        // Row 1
        inv.setItem(10, item(Material.ENDER_PEARL, "§b§lSpawn Ayarla",
                "§7Şu anki konumunu spawn yap",
                "§eTıkla → spawn güncellenir"));

        inv.setItem(12, item(Material.NAME_TAG, "§e§lPublic: " + (realm.isPublic() ? "§aAçık" : "§cKapalı"),
                "§7Herkes katılabilsin mi?",
                "§eTıkla → değiştir"));

        inv.setItem(14, item(Material.PAINTING, "§d§lResource Pack",
                "§7Şu an: " + (realm.getResourcePackUrl() != null ? "§aAyarlı" : "§cYok"),
                "§7URL ayarlamak için:",
                "§e/realm pack <url>",
                "§7Temizlemek için tıkla (varsa)"));

        inv.setItem(16, item(Material.OAK_SIGN, "§6§lScoreboard",
                "§7Durum: " + (realm.isScoreboardEnabled() ? "§aAçık" : "§cKapalı"),
                "§7Başlık: §f" + realm.getScoreboardTitle(),
                "§eSol tık: Aç/Kapat"));

        // Row 2
        inv.setItem(19, item(Material.PLAYER_HEAD, "§a§lÜyeler & Rank",
                "§7Toplam üye: §f" + realm.getMembers().size(),
                "§eTıkla → üye listesi (yakında)",
                "§7Rank atamak için komut kullan"));

        inv.setItem(21, item(Material.GRASS_BLOCK, "§2§lDünya Bilgisi",
                "§7World: §f" + realm.getWorldName(),
                "§7Tip: §f" + realm.getWorldType(),
                "§7ID: §f" + realm.getId()));

        inv.setItem(23, item(Material.WRITABLE_BOOK, "§e§lİsim Değiştir",
                "§7Şu anki isim: §f" + realm.getName(),
                "§7Değiştirmek için:",
                "§e/realm rename <yeni isim>",
                "§8(komut eklenecek)"));

        inv.setItem(28, item(Material.CHEST_MINECART, "§b§lPlugin Market",
                "§7Realm'ine eklenti kur / kaldır",
                "§eTıkla → Market'i aç"));

        inv.setItem(25, item(Material.TNT, "§4§lRealm'i Sil",
                "§cDİKKAT: Geri alınamaz!",
                "§7Onay için tekrar tıkla",
                "§eveya /realm admin delete " + realm.getId()));

        // Bottom
        inv.setItem(40, item(Material.ARROW, "§eGeri", "§7Ana menüye dön"));

        player.openInventory(inv);
    }

    private ItemStack item(Material mat, String name, String... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        List<String> lore = new ArrayList<>();
        for (String line : loreLines) {
            if (!line.isEmpty()) lore.add(line);
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}
