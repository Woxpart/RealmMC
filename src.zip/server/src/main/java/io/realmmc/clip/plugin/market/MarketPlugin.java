package io.realmmc.clip.plugin.market;

import org.bukkit.Material;
import java.util.List;

public class MarketPlugin {
    private final String id;
    private final String name;
    private final String description;
    private final String version;
    private final String author;
    private final Material icon;
    private final int price;
    private final List<String> commands;
    private final boolean builtin;

    public MarketPlugin(String id, String name, String description, String version,
                        String author, Material icon, int price, List<String> commands, boolean builtin) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.version = version;
        this.author = author;
        this.icon = icon;
        this.price = price;
        this.commands = commands;
        this.builtin = builtin;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getVersion() { return version; }
    public String getAuthor() { return author; }
    public Material getIcon() { return icon; }
    public int getPrice() { return price; }
    public List<String> getCommands() { return commands; }
    public boolean isBuiltin() { return builtin; }
}
